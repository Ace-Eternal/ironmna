import{j as e}from"./index-64bb86eb.js";const t=()=>e.jsx("div",{className:"flex-center",style:{width:"100%",height:"500px",fontSize:"32px"},children:"页面开发中。。。"});export{t as default};
